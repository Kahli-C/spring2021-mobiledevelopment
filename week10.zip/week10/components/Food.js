import React, {Component} from "React";
import {Stylesheet, Text, View } from "react-native";

export default class Food extends Component {
    render() {
        return (
            <View>
                <Text> Potatoes </Text>
            </View>
        );
    }
}
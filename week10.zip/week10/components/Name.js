import React, {Component} from "React";
import {Stylesheet, Text, View } from "react-native";

export default class Name extends Component {
    render() {
        return (
            <View>
                <Text> Kahli Clarke </Text>
            </View>
        );
    }
}
import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import {useState} from 'react';
import Constants from 'expo-constants';
import {Card} from 'react-native-elements';
import {Button} from 'react-native-elements'; 

export default function App() {
  const [pet, setPet] = useState();
    
  const [votes, setVotes] = useState(false);

  function increaseDogVote(value) {
    setPet('dogs');
    setVotes(true);
  }
  function increaseCatVote(value) {
    setPet('cats');
    setVotes(true);
  }
  function increaseParrotVote(value) {
    setPet('birds');
    setVotes(true);
  }

    return (
        <View style={styles.container}>
        { votes ? (
          <View style={styles.conatiner}>
            <Text>You voted for {pet}!</Text>
          </View>
        ) : (
          <View>
            <Text style={styles.headerText}>Vote for your Best Pet!</Text>
            <Card>
              <Button title="Dog" onPress={(value) => (increaseDogVote(dogs))}/>
            </Card>
          <Card.Divider/>
            <Card>
            <Button title="Cat" onPress={(value) => (increaseCatVote(cats))}/>
            </Card>  
          <Card.Divider/>
            <Card>
            <Button title="Parakeet" onPress={(value) => (increaseParrotVote(birds))}/>
            </Card>
            </View>
            )
        }    
            </View>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

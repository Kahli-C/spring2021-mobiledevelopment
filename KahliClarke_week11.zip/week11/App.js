import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Card, Button, Text } from 'react-native-elements';

export default function App() {
  return (
    <View style={styles.container}>
      <Card>
      <Text>Salmon Sushi</Text>
      <Text>Lamb Shawarma</Text>
      <StatusBar style="auto" />
      <Card.Divider />
        <Button title="SUBMIT"></Button>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

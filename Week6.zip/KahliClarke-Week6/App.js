import logo from './logo.svg';
import './App.css';
import Index from './Components/example'

function App() {
  return (
    <div className="App">
      <Index/> 
    </div>
  );
}

export default App;

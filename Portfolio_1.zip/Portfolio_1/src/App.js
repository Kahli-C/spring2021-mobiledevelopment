import './App.css';
import Title from './components/title/Title';
import Counter from './components/counter/Counter';

function App() {
  return (
    <div className="App">
     <Title/>
     <Counter/>
    </div>
  );
}

export default App;

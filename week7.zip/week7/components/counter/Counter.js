import React, { useState } from 'react'
import "./Counter.css"
function Counter() {
    const initialState = 0
    const [count, setCount] = useState(initialState)

    const incrementHandler = () =>{
        setCount(count + 1)
    }
    const resetHandler = () =>{
        setCount(initialState)
    }

    return (
        <div>
            <h3>Lap Count {count}</h3>
            <button onClick = {incrementHandler}>Increment</button>
            <button onClick = {resetHandler}>Reset</button>
        </div>
    )
}

export default Counter

import React from 'react'

function Title() {
    return (
        <div>
            <h1>Week7-Exercise Tracker</h1>
        </div>
    )
}

export default Title
